clc
clear
results=[];
for iiii=1:15
    save results.mat  results
    save iiii.mat iiii
    test2
    load iiii.mat
    load results.mat
    results=[results mmer];
end