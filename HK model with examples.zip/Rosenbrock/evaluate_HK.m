function y=evaluate_HK(x)
global dmodel
y=predictorh(x, dmodel);
end