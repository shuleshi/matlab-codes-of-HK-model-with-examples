function  [f df] = regpoly_c(S1)
global dmodelL1
[f df]=predictor(S1,dmodelL1);
% if  nargout > 1
%   [df] = predictor(S1,dmodel);
end