clear all
close all
global dmodel1
% global ff0 x1 x2 callt
%���ֵ����

%% ѵ����
lbx1=0.05;ubx1=0.15; 
lbx2=100;ubx2=50000; 
lbx3=63070;ubx3=115600; 
lbx4=990;ubx4=1110; 
lbx5=63.1;ubx5=116;
lbx6=700;ubx6=820;
lbx7=1120;ubx7=1680;
lbx8=9855;ubx8=12045;
tr=30
HH=(ubx1-lbx1).*rand(tr,1)+lbx1;
HH(:,2)=(ubx2-lbx2).*rand(tr,1)+lbx2;
HH(:,3)=(ubx3-lbx3).*rand(tr,1)+lbx3;
HH(:,4)=(ubx4-lbx4).*rand(tr,1)+lbx4;
HH(:,5)=(ubx5-lbx5).*rand(tr,1)+lbx5;
HH(:,6)=(ubx6-lbx6).*rand(tr,1)+lbx6;
HH(:,7)=(ubx7-lbx7).*rand(tr,1)+lbx7;
HH(:,8)=(ubx8-lbx8).*rand(tr,1)+lbx8;

fcn_u = 2.*pi.* HH(:,3).*(HH(:,4)-HH(:,6));
fcn_l = (1+(2.*HH(:,7).*HH(:,4))./(HH(:,1).^2.*HH(:,8).*log(HH(:,2)./HH(:,1)))+HH(:,3)./HH(:,5)).*log(HH(:,2)./HH(:,1));
y_fcn = fcn_u./fcn_l;

YE1 = y_fcn;

%% ���Լ�

ti=100;
test_HH=(ubx1-lbx1).*rand(ti,1)+lbx1;
test_HH(:,2)=(ubx2-lbx2).*rand(ti,1)+lbx2;
test_HH(:,3)=(ubx3-lbx3).*rand(ti,1)+lbx3;
test_HH(:,4)=(ubx4-lbx4).*rand(ti,1)+lbx4;
test_HH(:,5)=(ubx5-lbx5).*rand(ti,1)+lbx5;
test_HH(:,6)=(ubx6-lbx6).*rand(ti,1)+lbx6;
test_HH(:,7)=(ubx7-lbx7).*rand(ti,1)+lbx7;
test_HH(:,8)=(ubx8-lbx8).*rand(ti,1)+lbx8;

tesf_u = 2.*pi.* test_HH(:,3).*(test_HH(:,4)-test_HH(:,6));
tesf_l = (1+(2.*test_HH(:,7).*test_HH(:,4))./(test_HH(:,1).^2.*test_HH(:,8).*log(test_HH(:,2)./test_HH(:,1)))+test_HH(:,3)./test_HH(:,5)).*log(test_HH(:,2)./test_HH(:,1));
test_y = tesf_u./tesf_l;

 %%
% load('TR_TE_200_200_1.mat')%ѵ���������Լ�����
theta1=[0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1]; 
lob1=[1e-3 1e-3 1e-3 1e-3 1e-3 1e-3 1e-3 1e-3];
upb1=[100 100 100 100 100 100 100 100];
% HH=HH(:,1:2);
% YE1=HH(:,1);
[dmodel1,perf1]=dacefit(HH,YE1,@regpoly0,@corrgauss,theta1,lob1,upb1);
% load mydatatest500%���Լ�����
test=test_HH;
[YY1 YYMSE1]=predictor(test,dmodel1);
YT1=test_y ;
tic
%% accuracy
N1=size(test,1)
F1 = YY1; BJ1 = reshape(YT1,N1,1);
F1=reshape(F1,N1,1);
STD1=sqrt(sum((F1-sum(BJ1)/N1).^2)/(N1-1))%��׼��
MAE1=max(abs(F1-BJ1))%��ֵ
RMSE1=(sum((F1-BJ1).^2)/N1).^0.5%���������
R21 = (N1 * sum(BJ1.* F1) - sum(BJ1) * sum(F1))^2 / ((N1 * sum((BJ1).^2) - (sum(BJ1))^2) * (N1 * sum((F1).^2) - (sum(F1))^2))
R221=1-sum((F1-BJ1).^2)./sum((F1-sum(BJ1)/N1).^2)
RMAE1=max(abs(F1-BJ1))/STD1
RRMSE1=sqrt(sum((F1-BJ1).^2)/N1)/STD1
%% plot
XX=gridsamp([990 1120;1110 1680],40);
% XX=meshgrid(-2:0.02:2);
X(:,4) = XX(:,1);
X(:,7) = XX(:,2);

h1=(ubx1-lbx1).*rand(1,1)+lbx1;
X(:,1)=h1;
h2=(ubx2-lbx2).*rand(1,1)+lbx2;
X(:,2)=h2;
h3=(ubx3-lbx3).*rand(1,1)+lbx3;
X(:,3)=h3;
h5=(ubx5-lbx5).*rand(1,1)+lbx5;
X(:,5)=h5;
h6=(ubx6-lbx6).*rand(1,1)+lbx6;
X(:,6)=h6;
h8=(ubx8-lbx8).*rand(1,1)+lbx8;
X(:,8)=h8;

[YX MSE]=predictor(X,dmodel1);
X1=reshape(XX(:,1),40,40);
X2=reshape(XX(:,2),40,40);
YX=reshape(YX,size(X1));
figure(1),mesh(X1,X2,YX)
xlim([990 1110])
ylim([1120 1680])
set(gca,'FontName','Times New Roman','fontsize',11,'FontWeight','bold','xtick',990:40:1110,'ytick',1120:140:1680,'ztick',100:15:180) 
colorbar('FontName','Times New Roman','fontsize',11,'FontWeight','bold');
hold on,
% HHH=HH(:,1:2);
YEE1= y_fcn;
plot3(HH(:,4),HH(:,7),YEE1,'.k' ,'Markersize',10)
hold off