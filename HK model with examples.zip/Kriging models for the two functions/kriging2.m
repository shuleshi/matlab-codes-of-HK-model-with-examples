clear all
close all

global dmodel2
% global ff0 x1 x2 callt
%���ֵ����

% load('TR_TE_200_200_1.mat')%ѵ���������Լ�����

%% ѵ����
lbx1=-2.048;ubx1=2.048; 

tr2=30
HH2=(ubx1-lbx1).*rand(tr2,1)+lbx1;
HH2(:,2) =(ubx1-lbx1).*rand(tr2,1)+lbx1;

%     HH2=HH;
y_fcn2 = 100.*(HH2(:,1).^2-HH2(:,2)).^2 + (HH2(:,1)-1).^2 ;

YE2 = y_fcn2;

%% ���Լ�
ti=100;
test_dx1 = (ubx1-lbx1).*rand(ti,1)+lbx1;
test_dx2 = (ubx1-lbx1).*rand(ti,1)+lbx1;
test_HH2 = test_dx1;
test_HH2(:,2) = test_dx2;
test_y2 =  100.*(test_HH2(:,1).^2-test_HH2(:,2)).^2 + (test_HH2(:,1)-1).^2 ;

%%
% load('TR_TE_200_200_k2.mat')%ѵ���������Լ�����
theta2=[0.1 0.1]; 
lob2=[1e-3 1e-3];
upb2=[100 100];
% HH=HH(:,1:2);
% YE1=HH(:,1);
[dmodel2,perf1]=dacefit(HH2,YE2,@regpoly0,@corrgauss,theta2,lob2,upb2);
% load mydatatest500%���Լ�����
test2=test_HH2;
[YY2 YYMSE2]=predictor(test2,dmodel2);
YT2=test_y2 ;

%% accuracy
N2=size(test2,1)
F2 = YY2; BJ2 = reshape(YT2,N2,1);
F2=reshape(F2,N2,1);
STD2=sqrt(sum((F2-sum(BJ2)/N2).^2)/(N2-1))%��׼��
MAE2=max(abs(F2-BJ2))%��ֵ
RMSE2=(sum((F2-BJ2).^2)/N2).^0.5%���������
R21 = (N2 * sum(BJ2.* F2) - sum(BJ2) * sum(F2))^2 / ((N2 * sum((BJ2).^2) - (sum(BJ2))^2) * (N2 * sum((F2).^2) - (sum(F2))^2))
R221=1-sum((F2-BJ2).^2)./sum((F2-sum(BJ2)/N2).^2)
RMAE2=max(abs(F2-BJ2))/STD2
RRMSE2=sqrt(sum((F2-BJ2).^2)/N2)/STD2
%% plot
XX=gridsamp([-2.048 -2.048;2.048 2.048],40);
% XX=meshgrid(-2:0.02:2);
X = XX(:,1);
X(:,2) = XX(:,2);
[YX MSE]=predictor(X,dmodel2);
X1=reshape(X(:,1),40,40);
X2=reshape(X(:,2),40,40);
YX=reshape(YX,size(X1));
figure(2),mesh(X1,X2,YX)
xlim([-3 3])
ylim([-3 3])
set(gca,'FontName','Times New Roman','fontsize',11,'FontWeight','bold','xtick',-3:1:3,'ytick',-3:1:3,'ztick',0:500:3000) 
colorbar('FontName','Times New Roman','fontsize',11,'FontWeight','bold');
hold on,
HHH=HH2(:,1:2);
YEE2=y_fcn2;
plot3(HH2(:,1),HH2(:,2),YEE2,'.k' ,'Markersize',10)
hold off