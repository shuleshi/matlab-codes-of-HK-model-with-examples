function mer=metrics(TT,FF);
%% �����Ŵ��㷨����
N=length(TT);
MAE=max(abs(FF-TT));
RMSE=(sum((FF-TT).^2)/N).^0.5;
R2 = (N * sum(FF.* TT) - sum(FF) * sum(TT))^2 / ((N * sum((FF).^2) - (sum(FF))^2) * (N * sum((TT).^2) - (sum(TT))^2));
% STD=std(TT);
mer=[MAE RMSE];
% mer=[mer R2];

end



